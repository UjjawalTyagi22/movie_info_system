package com.example.movie_info_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieInfoSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
